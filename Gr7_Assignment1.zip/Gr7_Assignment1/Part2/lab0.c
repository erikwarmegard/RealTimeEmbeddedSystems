/*
    Part of the Real-Time Embedded Systems course at Halmstad University
    Copyright (c) 2016, Sebastian Kunze <sebastian.kunze@hh.se>
    All rights reserved.
*/

#include <rpi3.h>
//#include <stdio.h>


void delay(long unsigned int delayTime) {
    long unsigned int i = 0;

    while(i <= delayTime){
        i++;
    }
    return;
}

int main()
{
    /* Set initial delay time, clock Hz on kernel is appr. 700MHz */

     long unsigned int pauseTime = 350000; //change later

    /* Enable GPIO16 as an output */
    GPIO->GPFSEL1 |= (1 << 18);

    while(1)   {
      GPIO->GPCLR0 |= (1 << 16);
      pauseTime = pauseTime*2;
      delay(pauseTime);

  	GPIO->GPSET0 |= (1 << 16); //light up
      delay(700000); //our blink

    }

	return 0;
}
